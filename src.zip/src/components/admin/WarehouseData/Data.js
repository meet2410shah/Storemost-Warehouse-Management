const Data = [
    {
        id: "1",
        Address1 : "Lorem ipsum dolor sit amet,",
        Address2 : "consetetur sadipscing elitr,",
        Address3 : "Rajkot - 360 001" ,
        occupied : "65"
    },
    {
        id : "2",
        Address1 : "Lorem ipsum dolor sit amet,",
        Address2 : "consetetur sadipscing elitr,",
        Address3 : "Rajkot - 360 001" ,
        occupied : "70"
    }, 
    {
        id : "3",
        AAddress1 : "Lorem ipsum dolor sit amet,",
        Address2 : "consetetur sadipscing elitr,",
        Address3 : "Rajkot - 360 001" ,
        occupied : "68"
    },
    {
        id : "4",
        Address1 : "Lorem ipsum dolor sit amet,",
        Address2 : "consetetur sadipscing elitr,",
        Address3 : "Rajkot - 360 001" ,
        occupied : "10"
    },
     {
        id : "5",
        Address1 : "Lorem ipsum dolor sit amet,",
        Address2 : "consetetur sadipscing elitr,",
        Address3 : "Rajkot - 360 001" ,
        occupied : "50"
    },
    {
        id : "6",
        Address1 : "Lorem ipsum dolor sit amet,",
        Address2 : "consetetur sadipscing elitr,",
        Address3 : "bhavnagr - 360 001" ,
        occupied : "70"
    },
    {
        id : "7",
        Address1 : "Lorem ipsum dolor sit amet,",
        Address2 : "consetetur sadipscing elitr,",
        Address3 : "surat - 360 001" ,
        occupied : "70"
    },
    {
        id : "8",
        Address1 : "Lorem ipsum dolor sit amet,",
        Address2 : "consetetur sadipscing elitr,",
        Address3 : "Rajkot - 360 001" ,
        occupied : "70"
    },
    {
        id : "9",
        Address1 : "Lorem ipsum dolor sit amet,",
        Address2 : "consetetur sadipscing elitr,",
        Address3 : "Rajkot - 360 004" ,
        occupied : "70"
    },
    {
        id : "10",
        Address1 : "Lorem ipsum dolor sit amet,",
        Address2 : "consetetur sadipscing elitr,",
        Address3 : "Rajkot - 360 005" ,
        occupied : "70"
    },
    {
        id : "11",
        Address1 : "Lorem ipsum dolor sit amet,",
        Address2 : "consetetur sadipscing elitr,",
        Address3 : "Rajkot - 360 001" ,
        occupied : "70"
    },
    {
        id : "12",
        Address1 : "Lorem ipsum dolor sit amet,",
        Address2 : "consetetur sadipscing elitr,",
        Address3 : "Rajkot - 360 010" ,
        occupied : "70"
    },
    {
        id : "13",
        Address1 : "Lorem ipsum dolor sit amet,",
        Address2 : "consetetur sadipscing elitr,",
        Address3 : "Rajkot - 360 008" ,
        occupied : "25"
    },
]

export default Data;