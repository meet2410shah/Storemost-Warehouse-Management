const StaffData = [
    {
        name : "Abcd",
        position : "Supervisor",
        contact : "+91 9998700622"
    },
    {
        name : "Abcd",
        position : "Supervisor",
        contact : "+91 9998700622"
    }, 
    {
        name : "Abcd",
        position : "Supervisor",
        contact : "+91 9998700622"
    },
    {
        name : "Abcd",
        position : "Supervisor",
        contact : "+91 9998700622"
    },
     {
        name : "Abcd",
        position : "Supervisor",
        contact : "+91 9998700622"
    },
    {
        name : "Abcd",
        position : "Supervisor",
        contact : "+91 9998700622"
    },
    {
        name : "Abcd",
        position : "Supervisor",
        contact : "+91 9998700622"
    },
    {
        name : "Abcd",
        position : "Supervisor",
        contact : "+91 9998700622"
    },
    {
        name : "Abcd",
        position : "Supervisor",
        contact : "+91 9952700622"
    },
    {
        name : "Abcd",
        position : "Supervisor",
        contact : "+91 9998700622"
    },
    {
        name : "Abcd",
        position : "Supervisor",
        contact : "+91 9998700622"
    },
    {
        name : "Abcd",
        position : "Supervisor",
        contact : "+91 9998700622"
    },
    {
        name : "Abcd",
        position : "Supervisor",
        contact : "+91 9998700622"
    },
    {
        name : "Abcd",
        position : "Supervisor",
        contact : "+91 9998700622"
    },
    {
        name : "Abcd",
        position : "Supervisor",
        contact : "+91 9998700622"
    },
    {
        name : "Abcd",
        position : "Supervisor",
        contact : "+91 9998700622"
    },
    {
        name : "Abcd Efghit",
        position : "Supervisor",
        contact : "+91 9998700622"
    }
]

export default StaffData;