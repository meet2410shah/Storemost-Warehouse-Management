const CropsData = [
{
    //imgsrc = "./crops.png",
    name : "XYZ",
    ava : "121" 
},
{
   // imgsrc = "./crops.png",
    name : "XYZ",
    ava : "121" 
},
{
    //imgsrc = "./crops.png",
    name : "XYZ",
    ava : "121" 
},
{
   // imgsrc = "./crops.png",
    name : "XYZ",
    ava : "121" 
},
{
   // imgsrc = "./crops.png",
    name : "XYZ",
    ava : "121" 
},
{
    //imgsrc = "./crops.png",
    name : "XYZ",
    ava : "121" 
},
{
   // imgsrc = "./crops.png",
    name : "XYZ",
    ava : "121" 
},
{
    // imgsrc = "./crops.png",
     name : "XYZ",
     ava : "121" 
 },
 {
    // imgsrc = "./crops.png",
     name : "XYZ",
     ava : "121" 
 },
 {
    // imgsrc = "./crops.png",
     name : "XYZ",
     ava : "121" 
 },
 {
    // imgsrc = "./crops.png",
     name : "XYZ",
     ava : "121" 
 },
 {
    // imgsrc = "./crops.png",
     name : "XYZ",
     ava : "121" 
 },
 {
    // imgsrc = "./crops.png",
     name : "XYZ",
     ava : "121" 
 },
 {
    // imgsrc = "./crops.png",
     name : "XYZ",
     ava : "121" 
 },
 {
    // imgsrc = "./crops.png",
     name : "XYZ",
     ava : "121" 
 },
 {
    // imgsrc = "./crops.png",
     name : "XYZ",
     ava : "121" 
 },
 {
    // imgsrc = "./crops.png",
     name : "XYZ",
     ava : "121" 
 },
 {
    // imgsrc = "./crops.png",
     name : "XYZ",
     ava : "121" 
 },
]


export default CropsData;