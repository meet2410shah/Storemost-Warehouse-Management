const CustomersData = [
    {
        name : "Vandit Bhut",
        Deposit : "₹ 12,000",
        NoofCrops : "2",
        contact : "+91 9998700622",
        CropList : "Wheat, Cotton",
        DueDate : "21/05/2021"
    },
    {
        name : "Vandit Bhut",
        Deposit : "₹ 12,000",
        NoofCrops : "2",
        contact : "+91 9998700622",
        CropList : "Wheat, Cotton",
        DueDate : "21/05/2021"
    },
    {
        name : "Vandit Bhut",
        Deposit : "₹ 12,000",
        NoofCrops : "2",
        contact : "+91 9998700622",
        CropList : "Wheat, Cotton",
        DueDate : "21/05/2021"
    },
    {
        name : "Vandit Bhut",
        Deposit : "₹ 12,000",
        NoofCrops : "2",
        contact : "+91 9998700622",
        CropList : "Wheat, Cotton",
        DueDate : "21/05/2021"
    },
    {
        name : "Vandit Bhut",
        Deposit : "₹ 12,000",
        NoofCrops : "2",
        contact : "+91 9998700622",
        CropList : "Wheat, Cotton",
        DueDate : "21/05/2021"
    },
    {
        name : "Vandit Bhut",
        Deposit : "₹ 12,000",
        NoofCrops : "2",
        contact : "+91 9998700622",
        CropList : "Wheat, Cotton",
        DueDate : "21/05/2021"
    },
    {
        name : "Vandit Bhut",
        Deposit : "₹ 12,000",
        NoofCrops : "2",
        contact : "+91 9998700622",
        CropList : "Wheat, Cotton",
        DueDate : "21/05/2021"
    },
    {
        name : "Vandit Bhut",
        Deposit : "₹ 12,000",
        NoofCrops : "2",
        contact : "+91 9998700622",
        CropList : "Wheat, Cotton",
        DueDate : "21/05/2021"
    },
    {
        name : "Vandit Bhut",
        Deposit : "₹ 12,000",
        NoofCrops : "2",
        contact : "+91 9998700622",
        CropList : "Wheat, Cotton",
        DueDate : "21/05/2021"
    },
    {
        name : "Vandit Bhut",
        Deposit : "₹ 12,000",
        NoofCrops : "2",
        contact : "+91 9998700622",
        CropList : "Wheat, Cotton",
        DueDate : "21/05/2021"
    },
    {
        name : "Vandit Bhut",
        Deposit : "₹ 12,000",
        NoofCrops : "2",
        contact : "+91 9998700622",
        CropList : "Wheat, Cotton",
        DueDate : "21/05/2021"
    },
    {
        name : "Vandit Bhut",
        Deposit : "₹ 12,000",
        NoofCrops : "2",
        contact : "+91 9998700622",
        CropList : "Wheat, Cotton",
        DueDate : "21/05/2021"
    },
    {
        name : "Vandit Bhut",
        Deposit : "₹ 12,000",
        NoofCrops : "2",
        contact : "+91 9998700622",
        CropList : "Wheat, Cotton",
        DueDate : "21/05/2021"
    },
    {
        name : "Vandit Bhut",
        Deposit : "₹ 12,000",
        NoofCrops : "2",
        contact : "+91 9998700622",
        CropList : "Wheat, Cotton",
        DueDate : "21/05/2021"
    },
]

export default CustomersData;