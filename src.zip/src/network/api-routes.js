/**
 *
 * Author: MEET SHAH
 * Email: meet2410shah@gmail.com
 * Website: meet2410shah.herokuapp.com
 *
 */

// const version = "/api/v1";

export const auth = {
  hello: '/api/',
};
